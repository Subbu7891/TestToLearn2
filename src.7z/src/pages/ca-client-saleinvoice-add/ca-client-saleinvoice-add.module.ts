import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CaClientSaleinvoiceAddPage } from './ca-client-saleinvoice-add';

@NgModule({
  declarations: [
    CaClientSaleinvoiceAddPage,
  ],
  imports: [
    IonicPageModule.forChild(CaClientSaleinvoiceAddPage),
  ],
})
export class CaClientSaleinvoiceAddPageModule {}
