import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { OcBusinessGstinListPage } from './oc-business-gstin-list';

@NgModule({
  declarations: [
    OcBusinessGstinListPage,
  ],
  imports: [
    IonicPageModule.forChild(OcBusinessGstinListPage),
  ],
})
export class OcBusinessGstinListPageModule {}
