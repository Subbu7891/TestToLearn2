import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CaClientSaleinvoiceEditPage } from './ca-client-saleinvoice-edit';

@NgModule({
  declarations: [
    CaClientSaleinvoiceEditPage,
  ],
  imports: [
    IonicPageModule.forChild(CaClientSaleinvoiceEditPage),
  ],
})
export class CaClientSaleinvoiceEditPageModule {}
