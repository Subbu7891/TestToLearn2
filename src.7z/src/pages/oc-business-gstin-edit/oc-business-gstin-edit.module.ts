import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { OcBusinessGstinEditPage } from './oc-business-gstin-edit';

@NgModule({
  declarations: [
    OcBusinessGstinEditPage,
  ],
  imports: [
    IonicPageModule.forChild(OcBusinessGstinEditPage),
  ],
})
export class OcBusinessGstinEditPageModule {}
