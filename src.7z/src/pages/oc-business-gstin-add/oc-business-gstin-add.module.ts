import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { OcBusinessGstinAddPage } from './oc-business-gstin-add';

@NgModule({
  declarations: [
    OcBusinessGstinAddPage,
  ],
  imports: [
    IonicPageModule.forChild(OcBusinessGstinAddPage),
  ],
})
export class OcBusinessGstinAddPageModule {}
